

var Navbar = () => {
    return (
        <div style={{height:"80px", backgroundColor:"black",width:"1420px",paddingTop:"15px", marginBottom:"15px"}}>
            <h1 style={{color:"white"}}>Mobmart</h1>
        </div>
    )
}

export default Navbar;